-- 2nd Project

create database Stock_analysis;
use Stock_analysis;
drop table DJ;
drop table sp500;

select * from nas;
select * from dj;
select * from portf;
select * from portfp;
select * from sp500;

SET SQL_SAFE_UPDATES = 0;

-- Data type chanes as per requirment
alter table dj modify date date;
alter table dj modify returns double;
alter table nas modify date date;
alter table portfp modify date date;
alter table sp500 modify date date;

-- 1. What is the average monthly closing price for each index (Dow Jones, NASDAQ, S&P 500)?
SELECT
MONTH(nas.date) AS month,
AVG(nas.close) AS avg_close_nas,
AVG(dj.close) AS avg_close_dj,
AVG(sp500.close) AS avg_close_sp500
FROM nas
JOIN dj ON MONTH(nas.date) = MONTH(dj.date)
JOIN sp500 ON MONTH(nas.date) = MONTH(sp500.date)
GROUP BY MONTH(nas.date)
ORDER BY month;

-- 2. Which date had the highest single-day gain (percentage) for each index?
select dj.date,
	   (dj.returns*100) as dj_Percentage,
       (nas.returns*100) as nas_Percentage,
       (sp500.returns*100) as sp500_Percentage
from dj
join nas on dj.date=nas.date
join sp500 on dj.date=sp500.date
order by (dj.returns*100) DESC,
         (nas.returns*100) DESC,
         (sp500.returns*100) DESC
limit 1;

-- 3. Compare the performance (percentage change) of all three indices year over year.
WITH year_end_data AS (
    SELECT 
        YEAR(dj.date) AS year,
        dj.date,
        dj.close AS dj_close,
        nas.close AS nas_close,
        sp500.close AS sp500_close
    FROM dj
    JOIN nas ON dj.date = nas.date
    JOIN sp500 ON dj.date = sp500.date
    WHERE dj.date IN (
        SELECT MAX(date) 
        FROM dj 
        GROUP BY YEAR(date)
    )
)
SELECT 
    year,
    date,
    dj_close,
    LAG(dj_close) OVER (ORDER BY year) AS prev_dj_close,
    ROUND(((dj_close - LAG(dj_close) OVER (ORDER BY year)) / LAG(dj_close) OVER (ORDER BY year)) * 100, 2) AS dj_yoy_change,

    nas_close,
    LAG(nas_close) OVER (ORDER BY year) AS prev_nas_close,
    ROUND(((nas_close - LAG(nas_close) OVER (ORDER BY year)) / LAG(nas_close) OVER (ORDER BY year)) * 100, 2) AS nas_yoy_change,

    sp500_close,
    LAG(sp500_close) OVER (ORDER BY year) AS prev_sp500_close,
    ROUND(((sp500_close - LAG(sp500_close) OVER (ORDER BY year)) / LAG(sp500_close) OVER (ORDER BY year)) * 100, 2) AS sp500_yoy_change
FROM year_end_data;

-- 4. What is the total investment made by the user per stock in the portfolio?
select * from portf;
select * from portfp;
select ticker, round(sum(quantity*close),2) as Invested from portf
group by ticker;

-- 5. Which stock in the portfolio had the highest return as of the latest price?
WIth latest_price_data as (
select portf.ticker, portf.close as buy_price, portfp.close as latest_price from portf
join portfp on portf.ticker = portfp.ticker
where portfp.date in (select max(portfp.date) from portfp group by ticker)
order by portfp.close desc
)
select ticker, buy_price, latest_price, (((latest_price - buy_price)/buy_price)*100) as return_percentage from latest_price_data order by return_percentage desc;

-- 6. What is the total portfolio value at different points in time (e.g., monthly)?
with analysis as (
select portfp.ticker, month(portfp.date) as month_wise, portfp.date, portf.quantity, portfp.close, (portf.quantity * portfp.close) as stock_price from portfp
join portf on portfp.ticker = portf.ticker
)
select month_wise, sum(stock_price) as Investment from analysis group by month_wise order by month_wise;

-- 7. Which sector or stock type (if available in metadata) contributes the most to the current portfolio value?
select * from portf;
select sector, sum(weight) from portf
group by sector
order by sum(weight) desc
limit 1;

-- 8. Identify the worst performing month for the overall portfolio.
select * from portfp;
with month_data as (
select portf.ticker, portf.quantity as quantity, month(portfp.date) as Month, portfp.close as close from portfp
join portf on portfp.ticker = portf.ticker
where portfp.date in (select max(portfp.date) as max_date from portfp group by month(portfp.date))
),
month_data2 as (
select portf.ticker, Month, max_date from month_data group by portf.ticker, Month
),
monthly_stock_value as (
select Month, sum(close * quantity) as current_stock_value from month_data group by Month order by Month
)
select Month,
	   current_stock_value, 
	   LAG(current_stock_value) OVER (ORDER BY month) AS prev_current_stock_value,
	   ROUND(((current_stock_value - LAG(current_stock_value) OVER (ORDER BY month)) / LAG(current_stock_value) OVER (ORDER BY month)) * 100, 2) AS mom_change
       from monthly_stock_value
       order by mom_change;

-- 9. How does the user's portfolio compare with each index (NASDAQ, S&P 500, Dow Jones) over the last year?
select * from nas;
select * from dj;
select * from portf;
select * from portfp;
select * from sp500;
create view nas_view as 
with nas as (
select date, close as nas_close from nas
where date in (
               (SELECT MIN(date) FROM nas),
			   (SELECT MAX(date) FROM nas))
)
select date,
       nas_close,
       lag(nas_close) over (order by date) as nas_prev_close,
	   ROUND(((nas_close - LAG(nas_close) OVER (ORDER BY date)) / LAG(nas_close) OVER (ORDER BY date)) * 100, 2) AS returns
       from nas;
       
create view dj_view as 
with dj as (
select date, close as dj_close from dj
where date in (
               (SELECT MIN(date) FROM dj),
			   (SELECT MAX(date) FROM dj))
)
select date,
       dj_close,
       lag(dj_close) over (order by date) as dj_prev_close,
	   ROUND(((dj_close - LAG(dj_close) OVER (ORDER BY date)) / LAG(dj_close) OVER (ORDER BY date)) * 100, 2) AS returns
       from dj;

create view sp500_view as 
with sp500 as (
select date, close as sp500_close from sp500
where date in (
               (SELECT MIN(date) FROM sp500),
			   (SELECT MAX(date) FROM sp500))
)
select date,
       sp500_close,
       lag(sp500_close) over (order by date) as sp500_prev_close,
	   ROUND(((sp500_close - LAG(sp500_close) OVER (ORDER BY date)) / LAG(sp500_close) OVER (ORDER BY date)) * 100, 2) AS returns
       from sp500;

create view portfp_view as 
with portfp as (
select portf.ticker, portf.quantity, portfp.date, portfp.close as portfp_close, (portf.quantity * portfp.close) as invest from portfp
join portf on portf.ticker = portfp.ticker
where portfp.date in (
               (SELECT MIN(portfp.date) FROM portfp),
			   (SELECT MAX(portfp.date) FROM portfp))
),
sum_invest as (
select portfp.date as date,
       sum(invest) as latest_close from portfp
       group by portfp.date
)
select date,
	   latest_close,
       LAG(latest_close) OVER (ORDER BY date) as prev_close,
       ROUND(((latest_close - LAG(latest_close) OVER (ORDER BY date)) / LAG(latest_close) OVER (ORDER BY date)) * 100, 2) AS returns
       from sum_invest;
       
select * from nas_view;
select * from dj_view;
select * from sp500_view;
select * from portfp_view;
 
SELECT 'NASDAQ' AS source, date, nas_close AS close, returns FROM nas_view
UNION ALL
SELECT 'DOWJONES' AS source, date, dj_close AS close, returns FROM dj_view
UNION ALL
SELECT 'SP500' AS source, date, sp500_close AS close, returns FROM sp500_view
UNION ALL
SELECT 'PORTFOLIO' AS source, date, NULL AS close, returns FROM portfp_view;

SELECT 'NASDAQ' AS source, date, nas_close AS close, returns FROM nas_view
UNION ALL
SELECT 'DOWJONES' AS source, date, dj_close AS close, returns FROM dj_view
UNION ALL
SELECT 'SP500' AS source, date, sp500_close AS close, returns FROM sp500_view
UNION ALL
SELECT 'PORTFOLIO' AS source, date, NULL AS close, returns FROM portfp_view;

-- 10. On which dates did the portfolio outperform all three indices?
select * from nas;
select * from dj;
select * from portf;
select * from portfp;
select * from sp500;
with data as (
select portf.ticker, portf.quantity, portfp.date as date, portfp.returns as portf_return, nas.returns as nas_return, dj.returns as dj_return, sp500.returns as sp500_return from portfp 
join portf on portf.ticker = portfp.ticker
join nas on portfp.date = nas.date
join dj on portfp.date = dj.date
join sp500 on portfp.date = sp500.date
),
returns as (
select date, avg(portf_return) as portfolio_return, MAX(nas_return) AS nas_return, MAX(dj_return) AS dj_return, MAX(sp500_return) AS sp500_return from data group by date
),
final as (
select date, portfolio_return * 100 as portfolio_return, nas_return * 100 as nas_return, dj_return * 100 as dj_return, sp500_return*100 as sp500_return from returns
)
select date, portfolio_return, nas_return, dj_return, sp500_return from final where portfolio_return > nas_return AND portfolio_return > dj_return AND portfolio_return > sp500_return
	   order by date;